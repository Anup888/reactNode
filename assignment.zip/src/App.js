import React from 'react';
import './App.css';
import Home from "./views/home"
function App(props) {
  console.log("from app",props);
  return (
    <div className="App">
      <Home props={props}/>
    </div>
  );
}

export default App;
