import React, { Component } from "react";
import Header from "./layout/header/";
import Product from "./component/product";
import style from "./style.module.scss";

const productList = [
  {
    id: "1",
    name: "Laptop",
    category: ["1", "2"]
  },
  {
    id: "2",
    name: "mobile Laptop",
    category: ["1", "2"]
  }
];
class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectCategory: {},
    };
  }

  selectCategory = value => {
    console.log("from home", value);

    this.setState({
      selectCategory: value
    });
  };

  render() {
    console.log("from home", this.state);
    console.log("from home props", this.props);
    return (
      <div className="container">
        <Header
          title="Product Listing Page"
          selectCategory={this.selectCategory}
        />
        <div className={style["content__wrapper"]}>
          <Product props={this.props} productList={productList} categoryId={this.state.selectCategory.value} />
        </div>
      </div>
    );
  }
}

export default Home;
