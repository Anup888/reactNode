import React from "react";
import { Route, Switch } from "react-router-dom";
import ProductDetail from "./../component/productDetail";
import App from "./../../App";
import { withRouter } from 'react-router-dom'
const appRoutes = (props) => {
  console.log("from appRoutes",props);
  return (
    <Switch>
      <Route
        exact
        path="/"
        render={() => {
          return <App  props={props}/>;
        }}
      />
      <Route
        path={`/product/:productId`}
        render={() => {
          return <ProductDetail props={props}/>;
        }}
      />
    </Switch>
  );
};

export default withRouter(appRoutes);
