import React, { Component } from "react";
import Select from "react-select";
import style from "./style.module.scss"

class SubHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      options:props.options,
      value :props.options[0],
    };

  }

 handleChange = (value) =>{

    this.setState({
      value:value
    });
    
    this.props.selectCategory(value);

  }

  render() {
    console.log(this.props);
    console.log(this.state);
    const { title } = this.props;
    return (
      <div className={style["sub__header__wrapper"]}>
        <div className={style["item"]}>{title}</div>
        <div className={style["item"]}>
        <Select
                options={this.state.options}
                value={this.state.value}
                onChange={value => this.handleChange(value)}
                defaultValue={this.state.value}
            />
        </div>
      </div>
    );
  }
}

export default SubHeader;
