import React from "react";
import SubHeader from "./subheader";
import { useQuery } from "@apollo/react-hooks";
import { GET_CATEGORIES } from "./../../../queries/category";

import style from "./style.module.scss";
const Header = props => {
  console.log("from header", props);
  const { title } = props;
  const { data, loading, error } = useQuery(GET_CATEGORIES);
  console.log("data", data);
  let options = [];
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error</p>;
  if (data) {
    options = data.getCategories.map(item => {
      return {
        label: item.name,
        value: item.id
      };
    });
  }
  return (
    <>
      <div className="container">
        <div className="row">
          <div className={style["header__wraper"]}>
            <div className={style["header__title"]}> {title} </div>
          </div>
        </div>

        <div className="row">
          {props.selectCategory && (
            <SubHeader
              title="category"
              options={options}
              selectCategory={props.selectCategory}
            />
          )}
        </div>
      </div>
    </>
  );
};

export default Header;
