import React from "react";
import style from "./style.module.scss";
import imgAvtar from "./img_avatar.png";
import { useQuery } from "react-apollo";
import { GET_PRODUCTS_BY_CATEGORY } from "./../../../queries/product";
import { Link } from "react-router-dom";

const Product = props => {
  let categoryId = "1";
  if (props.categoryId) {
    categoryId = props.categoryId;
  }
  const { data, loading, error } = useQuery(GET_PRODUCTS_BY_CATEGORY, {
    variables: { categoryId }
  });

  if (loading) {
    return "loading .....";
  }
  if (error) {
    return error;
  }
  return (
    <>
      {data?.getProductBycategory?.map((item, index) => {
        return (
          <Link key={index} to={{pathname:`/product/${item.id}`,state:{
            productId:item.id,
            categoryId:categoryId
          }}}>
            <div className={style["card"]}>
              <img
                className={style["card__img"]}
                src={imgAvtar}
                alt={"Avatar"}
              />
              <div className={style["item__detail"]}>
                <h6>
                  <b>{item.name}</b>
                </h6>
                <p>{item.category}</p>
              </div>
            </div>
          </Link>
        );
      })}
    </>
  );
};

export default Product;
