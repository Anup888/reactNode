import React, { Component } from "react";
import style from "./style.module.scss";
import imgAvtar from "./img_avatar.png";
import Header from "./../../layout/header";
import {GET_PRODUCT} from "./../../../queries/product";
import { useQuery } from "react-apollo";
const ProductDetail = props => {
  // const { productDetail } = props;
  console.log("from productdetails",props);
  let id = props.props.location.state.productId;
  const { data, loading, error } = useQuery(GET_PRODUCT, {
    variables: { id:id }
  });

  if (loading) {
    return "loading .....";
  }
  if (error) {
    return error;
  }
  console.log("data from getProduct",data);
  return (
    <>
      <Header title="Product Detail Page"/>
      <div className={style["product__detail__container"]}>
        <div className={style["product__item"]}>
          <div className={style["item__img__container"]}>
            <img src={imgAvtar} alt="product" className={style["imgAvtar"]}/>
          </div>
          <div className={style["item_details__container"]}>
            {/* <div className={style["item__category"]}>TV</div> */}
            <div className={style["item__nme"]}>{`Name : ${data.getProduct.name}`}</div>
            <div className={style["item__discription"]}>
             {`Description : ${data.getProduct.description}`}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductDetail;
