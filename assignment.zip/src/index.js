import React from "react";
import ReactDOM from "react-dom";
import { Router } from "react-router-dom";
import "./index.css";
import * as serviceWorker from "./serviceWorker";
import history from "./history";
import { ApolloClient } from "apollo-client";
import { InMemoryCache } from "apollo-cache-inmemory";
import { HttpLink } from "apollo-link-http";
import { ApolloProvider } from "@apollo/react-hooks";
import AppRouter from "./views/router/appRouter";
const cache = new InMemoryCache();
const link = new HttpLink({
  uri: "http://localhost:8000/graphql"
});

const client = new ApolloClient({
  cache,
  link
});

ReactDOM.render(
  <ApolloProvider client={client}>
    <Router history={history}>
    <AppRouter/>
    </Router>
  </ApolloProvider>,
  document.getElementById("root")
);

serviceWorker.unregister();
