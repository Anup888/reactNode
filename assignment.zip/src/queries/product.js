import gql from "graphql-tag";

export const GET_PRODUCT = gql`
   query getProduct($id:String!) {
    getProduct(id:$id){
      id
      name
      description
    }
    }
`;



export const GET_PRODUCTS_BY_CATEGORY = gql`
  query getProductBycategory($categoryId:String) {
    getProductBycategory(categoryId:$categoryId){
      id
      name
      description
    }
    }
  
`;

